package com.unpas.masteringmaths.main

import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.module.AppGlideModule

@GlideModule
internal class AppGlideModule : AppGlideModule()