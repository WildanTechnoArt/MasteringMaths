package com.unpas.masteringmaths.main.activity

import android.content.Intent
import android.content.pm.ActivityInfo
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.unpas.masteringmaths.R
import com.unpas.masteringmaths.student.StudentRegisterActivity
import com.unpas.masteringmaths.teacher.activity.TeacherRegisterActivity
import kotlinx.android.synthetic.main.activity_choose_register.*

class ChooseRegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose_register)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        btn_register_student.setOnClickListener {
            startActivity(Intent(this, StudentRegisterActivity::class.java))
        }

        btn_register_teacher.setOnClickListener {
            startActivity(Intent(this, TeacherRegisterActivity::class.java))
        }

        btn_login.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
            finish()
        }
    }
}
