package com.unpas.masteringmaths.student.activity;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.unpas.masteringmaths.R;

public class StatisticActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_lesson);

    }
}
